# 1.3: Text and scrolling views

* Task 1: Add and edit TextView elements -->*(Project: ScrollingText)*
* Task 2: Add a ScrollView and an active web link -->*(Project: ScrollingText)*
* Task 3: Scroll multiple elements -->*(Project: ScrollingText2)*
* Coding challenge -->*(Project: ScrollingText3)*
* Homework -->*(Project: ScrollingText2HW)*
